import { useState } from 'react';
import { BookOpen, LogOut, Menu, X, Upload, LayoutGrid, FileText } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { Link, useRouter } from '@/lib/router';

export function Navbar() {
  const { user, signOut } = useAuth();
  const { navigate } = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
    setMobileOpen(false);
  };

  const navLinks = user ? (
    <>
      <Link
        to="/dashboard"
        onClick={() => setMobileOpen(false)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
      >
        <LayoutGrid size={18} />
        Dashboard
      </Link>
      <Link
        to="/my-notes"
        onClick={() => setMobileOpen(false)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
      >
        <FileText size={18} />
        My Notes
      </Link>
    </>
  ) : (
    <>
      <Link
        to="/signin"
        onClick={() => setMobileOpen(false)}
        className="px-4 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
      >
        Sign In
      </Link>
      <Link
        to="/signup"
        onClick={() => setMobileOpen(false)}
        className="px-4 py-2 rounded-lg bg-white text-slate-900 font-semibold hover:bg-slate-200 transition-colors"
      >
        Get Started
      </Link>
    </>
  );

  return (
    <nav className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2 text-white font-bold text-lg">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <BookOpen size={20} className="text-white" />
            </div>
            <span>NoteShare</span>
          </Link>

          <div className="hidden md:flex items-center gap-2">
            {navLinks}
            {user && (
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
              >
                <LogOut size={18} />
                Sign Out
              </button>
            )}
          </div>

          <button
            className="md:hidden text-white p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {mobileOpen && (
          <div className="md:hidden flex flex-col gap-2 pb-4">
            {navLinks}
            {user && (
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors text-left"
              >
                <LogOut size={18} />
                Sign Out
              </button>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}

export function UploadButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-[1.02] transition-all"
    >
      <Upload size={18} />
      Upload Notes
    </button>
  );
}
