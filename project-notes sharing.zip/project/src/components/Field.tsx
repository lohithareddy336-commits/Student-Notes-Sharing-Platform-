import { type InputHTMLAttributes, type TextareaHTMLAttributes } from 'react';

export function Input({
  label,
  error,
  ...props
}: { label: string; error?: string | null } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1.5">{label}</label>
      <input
        {...props}
        className={`w-full px-4 py-2.5 rounded-xl border bg-white text-slate-900 placeholder-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500/20 ${
          error ? 'border-red-400' : 'border-slate-200 focus:border-blue-500'
        }`}
      />
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
}

export function Textarea({
  label,
  error,
  ...props
}: { label: string; error?: string | null } & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1.5">{label}</label>
      <textarea
        {...props}
        className={`w-full px-4 py-2.5 rounded-xl border bg-white text-slate-900 placeholder-slate-400 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500/20 resize-none ${
          error ? 'border-red-400' : 'border-slate-200 focus:border-blue-500'
        }`}
      />
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
}

export function Select({
  label,
  error,
  children,
  ...props
}: { label: string; error?: string | null } & React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div>
      <label className="block text-sm font-medium text-slate-700 mb-1.5">{label}</label>
      <select
        {...props}
        className={`w-full px-4 py-2.5 rounded-xl border bg-white text-slate-900 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500/20 ${
          error ? 'border-red-400' : 'border-slate-200 focus:border-blue-500'
        }`}
      >
        {children}
      </select>
      {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
    </div>
  );
}
