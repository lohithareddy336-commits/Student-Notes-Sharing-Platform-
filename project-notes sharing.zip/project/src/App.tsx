import { useEffect } from 'react';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { RouterProvider, useRouter } from '@/lib/router';
import { Navbar } from '@/components/Navbar';
import { Landing } from '@/pages/Landing';
import { Auth } from '@/pages/Auth';
import { Dashboard } from '@/pages/Dashboard';
import { SubjectDetail } from '@/pages/SubjectDetail';
import { TopicDetail } from '@/pages/TopicDetail';
import { MyNotes } from '@/pages/MyNotes';

function Routes() {
  const { path, navigate } = useRouter();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user && (path === '/my-notes')) {
      navigate('/signin');
    }
  }, [loading, user, path, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="w-8 h-8 border-3 border-white/20 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  // Auth pages
  if (path === '/signin') return <Auth mode="signin" />;
  if (path === '/signup') return <Auth mode="signup" />;

  // Subject detail
  const subjectMatch = path.match(/^\/subject\/(.+)$/);
  if (subjectMatch) return <SubjectDetail subjectId={subjectMatch[1]} />;

  // Topic detail
  const topicMatch = path.match(/^\/topic\/(.+)$/);
  if (topicMatch) return <TopicDetail topicId={topicMatch[1]} />;

  // My Notes (protected)
  if (path === '/my-notes') {
    if (!user) return <Auth mode="signin" />;
    return <MyNotes />;
  }

  // Home page
  if (path === '/') return <Landing />;

  // Dashboard
  if (path === '/dashboard') return <Dashboard />;

  // Fallback
  return <Dashboard />;
}

function App() {
  return (
    <AuthProvider>
      <RouterProvider>
        <div className="min-h-screen bg-slate-50">
          <Navbar />
          <Routes />
        </div>
      </RouterProvider>
    </AuthProvider>
  );
}

export default App;
