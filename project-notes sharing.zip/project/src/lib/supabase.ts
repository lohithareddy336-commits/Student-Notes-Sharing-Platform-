import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type Subject = {
  id: string;
  name: string;
  code: string;
  description: string;
  color: string;
  created_at: string;
};

export type Topic = {
  id: string;
  subject_id: string;
  name: string;
  description: string;
  created_at: string;
};

export type Note = {
  id: string;
  topic_id: string;
  uploader_id: string;
  title: string;
  description: string;
  file_path: string;
  file_name: string;
  file_size: number;
  file_type: string;
  downloads: number;
  created_at: string;
};

export type NoteWithTopic = Note & {
  topic: { id: string; name: string; subject_id: string };
};
