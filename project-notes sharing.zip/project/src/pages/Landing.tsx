import { useEffect, useState } from 'react';
import {
  BookOpen,
  Upload,
  Search,
  Users,
  Shield,
  ArrowRight,
  FileText,
  GraduationCap,
  Sparkles,
} from 'lucide-react';
import { Link } from '@/lib/router';
import { supabase, type Subject } from '@/lib/supabase';

export function Landing() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [stats, setStats] = useState({ subjects: 0, topics: 0, notes: 0 });

  useEffect(() => {
    (async () => {
      const { data: subs } = await supabase.from('subjects').select('*').limit(6);
      if (subs) setSubjects(subs);

      const [s, t, n] = await Promise.all([
        supabase.from('subjects').select('id', { count: 'exact', head: true }),
        supabase.from('topics').select('id', { count: 'exact', head: true }),
        supabase.from('notes').select('id', { count: 'exact', head: true }),
      ]);
      setStats({
        subjects: s.count ?? 0,
        topics: t.count ?? 0,
        notes: n.count ?? 0,
      });
    })();
  }, []);

  return (
    <div className="bg-slate-50">
      {/* Hero */}
      <section className="relative overflow-hidden bg-slate-900">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-slate-900 to-cyan-600/10" />
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              'url("data:image/svg+xml,%3Csvg width="60" height="60" xmlns="http://www.w3.org/2000/svg"%3E%3Cpath d="M30 0L60 30L30 60L0 30Z" fill="white"/%3E%3C/svg%3E")',
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20 sm:py-28">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-white/15 text-cyan-300 text-sm font-medium mb-6">
              <Sparkles size={16} />
              Share knowledge. Ace your exams.
            </div>
            <h1 className="text-4xl sm:text-6xl font-bold text-white leading-tight tracking-tight">
              The platform where{' '}
              <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
                students share notes
              </span>{' '}
              effortlessly
            </h1>
            <p className="mt-6 text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
              Upload, organize, and access subject notes all in one place. Browse by subject,
              dive into topics, and download what you need — anytime.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/signup"
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold shadow-xl shadow-blue-500/30 hover:shadow-blue-500/50 hover:scale-[1.02] transition-all"
              >
                Get Started Free
                <ArrowRight size={18} />
              </Link>
              <Link
                to="/dashboard"
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white/10 border border-white/15 text-white font-semibold hover:bg-white/20 transition-all"
              >
                <Search size={18} />
                Browse Notes
              </Link>
            </div>

            {/* Stats */}
            <div className="mt-16 grid grid-cols-3 gap-4 sm:gap-8 max-w-2xl mx-auto">
              {[
                { label: 'Subjects', value: stats.subjects, icon: BookOpen },
                { label: 'Topics', value: stats.topics, icon: FileText },
                { label: 'Notes', value: stats.notes, icon: Upload },
              ].map(({ label, value, icon: Icon }) => (
                <div
                  key={label}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl bg-white/5 border border-white/10"
                >
                  <Icon size={22} className="text-cyan-400" />
                  <span className="text-2xl font-bold text-white">{value}</span>
                  <span className="text-sm text-slate-400">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-20">
        <div className="text-center mb-14">
          <h2 className="text-3xl font-bold text-slate-900">Everything you need to collaborate</h2>
          <p className="mt-3 text-slate-600 max-w-2xl mx-auto">
            Built for students, by students. A clean, organized hub for all your course materials.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: Upload,
              title: 'Easy Upload',
              desc: 'Drag, drop, and share. Upload PDFs, docs, and images in seconds with automatic organization.',
              color: 'from-blue-500 to-blue-600',
            },
            {
              icon: Search,
              title: 'Smart Browsing',
              desc: 'Navigate by subject and topic to find exactly what you need without endless scrolling.',
              color: 'from-cyan-500 to-teal-500',
            },
            {
              icon: Shield,
              title: 'Secure & Reliable',
              desc: 'Your files are stored safely with role-based access. You control what you share.',
              color: 'from-emerald-500 to-green-600',
            },
          ].map(({ icon: Icon, title, desc, color }) => (
            <div
              key={title}
              className="group p-8 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-xl hover:border-slate-200 transition-all duration-300"
            >
              <div
                className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}
              >
                <Icon size={24} className="text-white" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">{title}</h3>
              <p className="text-slate-600 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Subjects Preview */}
      {subjects.length > 0 && (
        <section className="bg-white py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex items-end justify-between mb-10">
              <div>
                <h2 className="text-3xl font-bold text-slate-900">Popular Subjects</h2>
                <p className="mt-2 text-slate-600">Explore notes across different courses</p>
              </div>
              <Link
                to="/dashboard"
                className="hidden sm:flex items-center gap-1 text-blue-600 font-medium hover:gap-2 transition-all"
              >
                View all <ArrowRight size={18} />
              </Link>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {subjects.map((subject) => (
                <Link
                  key={subject.id}
                  to={`/subject/${subject.id}`}
                  className="group p-6 rounded-2xl border border-slate-100 hover:shadow-lg hover:border-slate-200 transition-all"
                >
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: `${subject.color}20` }}
                  >
                    <GraduationCap size={22} style={{ color: subject.color }} />
                  </div>
                  <div className="text-sm font-mono text-slate-400 mb-1">{subject.code}</div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {subject.name}
                  </h3>
                  <p className="mt-1 text-sm text-slate-500 line-clamp-2">
                    {subject.description || 'No description available'}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="bg-slate-900 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center">
          <Users size={40} className="text-cyan-400 mx-auto mb-5" />
          <h2 className="text-3xl font-bold text-white">Ready to start sharing?</h2>
          <p className="mt-3 text-slate-400 text-lg">
            Join your peers and never miss a lecture's notes again.
          </p>
          <Link
            to="/signup"
            className="mt-8 inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold shadow-xl shadow-blue-500/30 hover:scale-[1.02] transition-all"
          >
            Create your account
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
}
