import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Plus,
  FileText,
  ChevronRight,
  Pencil,
  Trash2,
  BookOpen,
  GraduationCap,
} from 'lucide-react';
import { supabase, type Subject, type Topic } from '@/lib/supabase';
import { useAuth } from '@/lib/AuthContext';
import { Link, useRouter } from '@/lib/router';
import { Modal } from '@/components/Modal';
import { Input, Textarea } from '@/components/Field';

type TopicWithNotes = Topic & { note_count: number };

export function SubjectDetail({ subjectId }: { subjectId: string }) {
  const { user } = useAuth();
  const { navigate } = useRouter();
  const [subject, setSubject] = useState<Subject | null>(null);
  const [topics, setTopics] = useState<TopicWithNotes[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTopic, setEditingTopic] = useState<Topic | null>(null);

  const loadData = async () => {
    const { data: sub } = await supabase
      .from('subjects')
      .select('*')
      .eq('id', subjectId)
      .maybeSingle();
    setSubject(sub as Subject | null);

    const { data: tops } = await supabase
      .from('topics')
      .select('*')
      .eq('subject_id', subjectId)
      .order('name');

    if (tops) {
      const enriched = await Promise.all(
        tops.map(async (t) => {
          const { count } = await supabase
            .from('notes')
            .select('id', { count: 'exact', head: true })
            .eq('topic_id', t.id);
          return { ...t, note_count: count ?? 0 };
        })
      );
      setTopics(enriched as TopicWithNotes[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [subjectId]);

  if (!loading && !subject) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <BookOpen size={48} className="text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-700">Subject not found</h3>
          <Link to="/dashboard" className="mt-4 inline-flex items-center gap-1.5 text-blue-600 font-medium">
            <ArrowLeft size={16} /> Back to subjects
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50">
      {/* Hero banner */}
      <div
        className="relative h-44 sm:h-52 overflow-hidden"
        style={{
          background: `linear-gradient(135deg, ${subject?.color ?? '#3b82f6'}40, ${subject?.color ?? '#3b82f6'}10)`,
        }}
      >
        <div className="absolute inset-0 bg-slate-900/30" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 h-full flex flex-col justify-end pb-6">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center gap-1.5 text-white/80 hover:text-white text-sm mb-3 transition-colors"
          >
            <ArrowLeft size={16} /> All Subjects
          </button>
          <div className="flex items-center gap-3">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0"
              style={{ backgroundColor: `${subject?.color ?? '#3b82f6'}30` }}
            >
              <GraduationCap size={28} style={{ color: subject?.color ?? '#3b82f6' }} />
            </div>
            <div>
              <div className="text-sm font-mono text-white/70">{subject?.code}</div>
              <h1 className="text-2xl sm:text-3xl font-bold text-white">{subject?.name}</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {subject?.description && (
          <p className="text-slate-600 mb-6 max-w-2xl">{subject.description}</p>
        )}

        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-slate-900">
            Topics {topics.length > 0 && `(${topics.length})`}
          </h2>
          {user && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white border border-slate-200 text-slate-600 font-medium hover:bg-slate-50 transition-colors text-sm"
            >
              <Plus size={16} /> Add Topic
            </button>
          )}
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-32 rounded-2xl bg-white border border-slate-100 animate-pulse" />
            ))}
          </div>
        ) : topics.length === 0 ? (
          <div className="text-center py-16 rounded-2xl bg-white border border-slate-100">
            <FileText size={40} className="text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-slate-700">No topics yet</h3>
            <p className="mt-1 text-slate-500">
              {user ? 'Add a topic to start organizing notes' : 'Check back soon for content'}
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {topics.map((topic) => (
              <div
                key={topic.id}
                className="group relative p-5 rounded-2xl bg-white border border-slate-100 hover:shadow-lg hover:border-slate-200 transition-all"
              >
                <Link
                  to={`/topic/${topic.id}`}
                  className="block"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">
                        {topic.name}
                      </h3>
                      {topic.description && (
                        <p className="mt-1 text-sm text-slate-500 line-clamp-2">{topic.description}</p>
                      )}
                    </div>
                    <ChevronRight
                      size={18}
                      className="text-slate-300 group-hover:text-blue-500 group-hover:translate-x-0.5 transition-all shrink-0"
                    />
                  </div>
                  <div className="mt-3 flex items-center gap-1.5 text-sm text-slate-400">
                    <FileText size={14} />
                    {topic.note_count} {topic.note_count === 1 ? 'note' : 'notes'}
                  </div>
                </Link>

                {user && (
                  <div className="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => setEditingTopic(topic)}
                      className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-blue-600 hover:border-blue-300 transition-colors shadow-sm"
                    >
                      <Pencil size={13} />
                    </button>
                    <button
                      onClick={async () => {
                        if (confirm(`Delete "${topic.name}" and all its notes?`)) {
                          await supabase.from('topics').delete().eq('id', topic.id);
                          loadData();
                        }
                      }}
                      className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-red-500 hover:border-red-300 transition-colors shadow-sm"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <TopicModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSaved={loadData}
        subjectId={subjectId}
      />
      <TopicModal
        open={!!editingTopic}
        onClose={() => setEditingTopic(null)}
        onSaved={loadData}
        subjectId={subjectId}
        topic={editingTopic}
      />
    </div>
  );
}

function TopicModal({
  open,
  onClose,
  onSaved,
  subjectId,
  topic,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  subjectId: string;
  topic?: Topic | null;
}) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName(topic?.name ?? '');
      setDescription(topic?.description ?? '');
      setError(null);
    }
  }, [open, topic]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = { name, description, subject_id: subjectId };
    const { error: err } = topic
      ? await supabase.from('topics').update({ name, description }).eq('id', topic.id)
      : await supabase.from('topics').insert(payload);

    setSaving(false);
    if (err) {
      setError(err.message);
    } else {
      onSaved();
      onClose();
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={topic ? 'Edit Topic' : 'Add Topic'}>
      <form onSubmit={handleSave} className="space-y-4">
        <Input
          label="Topic Name"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Sorting Algorithms"
        />
        <Textarea
          label="Description"
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description of this topic"
        />
        {error && (
          <div className="px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-600">
            {error}
          </div>
        )}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-medium hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50"
          >
            {saving ? 'Saving...' : topic ? 'Save Changes' : 'Add Topic'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
