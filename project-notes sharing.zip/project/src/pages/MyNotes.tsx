import { useEffect, useState } from 'react';
import {
  FileText,
  Download,
  Trash2,
  Pencil,
  File,
  ImageIcon,
  FileType,
  BookOpen,
  ArrowLeft,
} from 'lucide-react';
import { supabase, type NoteWithTopic } from '@/lib/supabase';
import { useAuth } from '@/lib/AuthContext';
import { Link, useRouter } from '@/lib/router';
import { Modal } from '@/components/Modal';
import { Input, Textarea } from '@/components/Field';
import { formatBytes, timeAgo } from '@/lib/utils';

export function MyNotes() {
  const { user } = useAuth();
  const { navigate } = useRouter();
  const [notes, setNotes] = useState<NoteWithTopic[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingNote, setEditingNote] = useState<NoteWithTopic | null>(null);

  const loadData = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('notes')
      .select('*, topic:topics(id, name, subject_id)')
      .eq('uploader_id', user.id)
      .order('created_at', { ascending: false });
    setNotes((data as NoteWithTopic[]) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleDownload = async (note: NoteWithTopic) => {
    const { data } = await supabase.storage
      .from('notes-files')
      .createSignedUrl(note.file_path, 3600);
    if (data) window.open(data.signedUrl, '_blank');
  };

  const handleDelete = async (note: NoteWithTopic) => {
    if (!confirm('Delete this note permanently?')) return;
    await supabase.storage.from('notes-files').remove([note.file_path]);
    await supabase.from('notes').delete().eq('id', note.id);
    loadData();
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return ImageIcon;
    if (fileType.includes('pdf')) return FileText;
    if (fileType.includes('word') || fileType.includes('document')) return FileType;
    return File;
  };

  if (!user) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <BookOpen size={48} className="text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-700">Please sign in</h3>
          <p className="mt-1 text-slate-500">You need an account to view your notes</p>
          <Link to="/signin" className="mt-4 inline-flex items-center gap-1.5 text-blue-600 font-medium">
            Sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-1.5 text-slate-400 hover:text-slate-700 text-sm mb-4 transition-colors"
        >
          <ArrowLeft size={16} /> Dashboard
        </button>

        <h1 className="text-3xl font-bold text-slate-900">My Notes</h1>
        <p className="mt-1 text-slate-500">All notes you've uploaded across subjects</p>

        <div className="mt-8">
          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-24 rounded-2xl bg-white border border-slate-100 animate-pulse" />
              ))}
            </div>
          ) : notes.length === 0 ? (
            <div className="text-center py-16 rounded-2xl bg-white border border-slate-100">
              <FileText size={40} className="text-slate-300 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-slate-700">No notes uploaded yet</h3>
              <p className="mt-1 text-slate-500">
                Browse subjects and upload your first note
              </p>
              <Link
                to="/dashboard"
                className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold shadow-lg shadow-blue-500/25 hover:scale-[1.02] transition-all"
              >
                Browse Subjects
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {notes.map((note) => {
                const Icon = getFileIcon(note.file_type);
                return (
                  <div
                    key={note.id}
                    className="group flex items-center gap-4 p-5 rounded-2xl bg-white border border-slate-100 hover:shadow-md hover:border-slate-200 transition-all"
                  >
                    <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                      <Icon size={22} className="text-slate-400" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-slate-900 truncate">{note.title}</h3>
                      {note.description && (
                        <p className="text-sm text-slate-500 truncate">{note.description}</p>
                      )}
                      <div className="mt-1.5 flex items-center gap-3 text-xs text-slate-400">
                        <Link
                          to={`/topic/${note.topic.id}`}
                          className="text-blue-500 hover:underline"
                        >
                          {note.topic.name}
                        </Link>
                        <span>{formatBytes(note.file_size)}</span>
                        <span className="flex items-center gap-1">
                          <Download size={12} /> {note.downloads}
                        </span>
                        <span className="hidden sm:inline">{timeAgo(note.created_at)}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleDownload(note)}
                        className="p-2 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
                      >
                        <Download size={16} />
                      </button>
                      <button
                        onClick={() => setEditingNote(note)}
                        className="p-2 rounded-lg text-slate-300 hover:text-blue-600 transition-colors"
                      >
                        <Pencil size={15} />
                      </button>
                      <button
                        onClick={() => handleDelete(note)}
                        className="p-2 rounded-lg text-slate-300 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {editingNote && (
        <EditNoteModal
          open={!!editingNote}
          onClose={() => setEditingNote(null)}
          onSaved={loadData}
          note={editingNote}
        />
      )}
    </div>
  );
}

function EditNoteModal({
  open,
  onClose,
  onSaved,
  note,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  note: NoteWithTopic;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setTitle(note.title);
      setDescription(note.description);
      setError(null);
    }
  }, [open, note]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { error: err } = await supabase
      .from('notes')
      .update({ title, description })
      .eq('id', note.id);
    setSaving(false);
    if (err) {
      setError(err.message);
    } else {
      onSaved();
      onClose();
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Edit Note">
      <form onSubmit={handleSave} className="space-y-4">
        <Input label="Title" required value={title} onChange={(e) => setTitle(e.target.value)} />
        <Textarea
          label="Description"
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        {error && (
          <div className="px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-600">
            {error}
          </div>
        )}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-medium hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
