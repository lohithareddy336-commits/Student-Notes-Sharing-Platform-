import { useEffect, useState } from 'react';
import {
  GraduationCap,
  Plus,
  Search,
  BookOpen,
  FileText,
  ChevronRight,
  Pencil,
  Trash2,
} from 'lucide-react';
import { supabase, type Subject } from '@/lib/supabase';
import { useAuth } from '@/lib/AuthContext';
import { Link } from '@/lib/router';
import { Modal } from '@/components/Modal';
import { Input, Textarea } from '@/components/Field';
import { UploadButton } from '@/components/Navbar';

type SubjectWithCounts = Subject & {
  topic_count: number;
  note_count: number;
};

export function Dashboard() {
  const { user } = useAuth();
  const [subjects, setSubjects] = useState<SubjectWithCounts[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);

  const colors = ['#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'];

  const loadSubjects = async () => {
    const { data } = await supabase.from('subjects').select('*').order('name');
    if (!data) return;

    const enriched = await Promise.all(
      data.map(async (s) => {
        const { count: topicCount } = await supabase
          .from('topics')
          .select('id', { count: 'exact', head: true })
          .eq('subject_id', s.id);
        const { count: noteCount } = await supabase
          .from('notes')
          .select('id', { count: 'exact', head: true })
          .eq('topic.subject_id', s.id);
        return { ...s, topic_count: topicCount ?? 0, note_count: noteCount ?? 0 };
      })
    );
    setSubjects(enriched as SubjectWithCounts[]);
    setLoading(false);
  };

  useEffect(() => {
    loadSubjects();
  }, []);

  const filtered = subjects.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.code.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Subjects</h1>
            <p className="mt-1 text-slate-500">
              {user ? 'Browse and manage your subjects' : 'Explore notes by subject'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {user && <UploadButton onClick={() => setShowAddModal(true)} />}
          </div>
        </div>

        {/* Search bar */}
        <div className="relative mb-8 max-w-md">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search subjects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors"
          />
        </div>

        {/* Grid */}
        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="h-48 rounded-2xl bg-white border border-slate-100 animate-pulse"
              />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen size={48} className="text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-700">
              {search ? 'No subjects found' : 'No subjects yet'}
            </h3>
            <p className="mt-1 text-slate-500">
              {user
                ? 'Add your first subject to get started'
                : 'Check back soon for new content'}
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((subject) => (
              <div
                key={subject.id}
                className="group relative p-6 rounded-2xl bg-white border border-slate-100 hover:shadow-xl hover:border-slate-200 transition-all duration-300"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${subject.color}20` }}
                >
                  <GraduationCap size={24} style={{ color: subject.color }} />
                </div>
                <div className="text-sm font-mono text-slate-400 mb-1">{subject.code}</div>
                <h3 className="text-lg font-bold text-slate-900">{subject.name}</h3>
                <p className="mt-1 text-sm text-slate-500 line-clamp-2 min-h-[2.5rem]">
                  {subject.description || 'No description available'}
                </p>

                <div className="mt-4 flex items-center gap-4 text-sm text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <BookOpen size={15} />
                    {subject.topic_count} topics
                  </span>
                  <span className="flex items-center gap-1.5">
                    <FileText size={15} />
                    {subject.note_count} notes
                  </span>
                </div>

                <Link
                  to={`/subject/${subject.id}`}
                  className="mt-4 flex items-center justify-between w-full px-4 py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium text-sm transition-colors"
                >
                  View Topics
                  <ChevronRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
                </Link>

                {user && (
                  <div className="absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => setEditingSubject(subject)}
                      className="p-2 rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-blue-600 hover:border-blue-300 transition-colors shadow-sm"
                    >
                      <Pencil size={14} />
                    </button>
                    <button
                      onClick={async () => {
                        if (confirm(`Delete "${subject.name}"? This removes all topics and notes.`)) {
                          await supabase.from('subjects').delete().eq('id', subject.id);
                          loadSubjects();
                        }
                      }}
                      className="p-2 rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-red-500 hover:border-red-300 transition-colors shadow-sm"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {user && filtered.length > 0 && (
          <div className="mt-8 text-center">
            <button
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-600 font-medium hover:bg-slate-50 transition-colors"
            >
              <Plus size={18} />
              Add Subject
            </button>
          </div>
        )}
      </div>

      <SubjectModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSaved={loadSubjects}
        colors={colors}
      />
      <SubjectModal
        open={!!editingSubject}
        onClose={() => setEditingSubject(null)}
        onSaved={loadSubjects}
        subject={editingSubject}
        colors={colors}
      />
    </div>
  );
}

function SubjectModal({
  open,
  onClose,
  onSaved,
  subject,
  colors,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  subject?: Subject | null;
  colors: string[];
}) {
  const [name, setName] = useState(subject?.name ?? '');
  const [code, setCode] = useState(subject?.code ?? '');
  const [description, setDescription] = useState(subject?.description ?? '');
  const [color, setColor] = useState(subject?.color ?? colors[0]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName(subject?.name ?? '');
      setCode(subject?.code ?? '');
      setDescription(subject?.description ?? '');
      setColor(subject?.color ?? colors[0]);
      setError(null);
    }
  }, [open, subject, colors]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = { name, code: code.toUpperCase(), description, color };
    const { error: err } = subject
      ? await supabase.from('subjects').update(payload).eq('id', subject.id)
      : await supabase.from('subjects').insert(payload);

    setSaving(false);
    if (err) {
      setError(err.message);
    } else {
      onSaved();
      onClose();
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={subject ? 'Edit Subject' : 'Add Subject'}>
      <form onSubmit={handleSave} className="space-y-4">
        <Input
          label="Subject Name"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Data Structures"
        />
        <Input
          label="Subject Code"
          required
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="e.g. CS201"
        />
        <Textarea
          label="Description"
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description of the subject"
        />
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Color</label>
          <div className="flex flex-wrap gap-2">
            {colors.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={`w-9 h-9 rounded-lg transition-transform ${
                  color === c ? 'ring-2 ring-offset-2 ring-slate-400 scale-110' : 'hover:scale-105'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>
        {error && (
          <div className="px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-600">
            {error}
          </div>
        )}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-medium hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50"
          >
            {saving ? 'Saving...' : subject ? 'Save Changes' : 'Add Subject'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
