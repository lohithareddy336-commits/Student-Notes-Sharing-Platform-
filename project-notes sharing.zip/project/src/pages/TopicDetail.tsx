import { useEffect, useState, useRef } from 'react';
import {
  ArrowLeft,
  FileText,
  Download,
  Trash2,
  Upload,
  Pencil,
  File,
  ImageIcon,
  FileType,
} from 'lucide-react';
import { supabase, type Topic, type Subject, type Note } from '@/lib/supabase';
import { useAuth } from '@/lib/AuthContext';
import { Link, useRouter } from '@/lib/router';
import { Modal } from '@/components/Modal';
import { Input, Textarea } from '@/components/Field';
import { formatBytes, timeAgo } from '@/lib/utils';

export function TopicDetail({ topicId }: { topicId: string }) {
  const { user } = useAuth();
  const { navigate } = useRouter();
  const [topic, setTopic] = useState<(Topic & { subject: Subject }) | null>(null);
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);

  const loadData = async () => {
    const { data: top } = await supabase
      .from('topics')
      .select('*, subject:subjects(*)')
      .eq('id', topicId)
      .maybeSingle();
    setTopic(top as (Topic & { subject: Subject }) | null);

    const { data: ns } = await supabase
      .from('notes')
      .select('*')
      .eq('topic_id', topicId)
      .order('created_at', { ascending: false });
    setNotes((ns as Note[]) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [topicId]);

  const handleDownload = async (note: Note) => {
    const { data, error } = await supabase.storage
      .from('notes-files')
      .createSignedUrl(note.file_path, 3600);

    if (error || !data) {
      const { data: pub } = supabase.storage.from('notes-files').getPublicUrl(note.file_path);
      if (pub?.publicUrl) {
        window.open(pub.publicUrl, '_blank');
      }
      return;
    }

    window.open(data.signedUrl, '_blank');
    await supabase.from('notes').update({ downloads: note.downloads + 1 }).eq('id', note.id);
    loadData();
  };

  const handleDeleteNote = async (note: Note) => {
    if (!confirm('Delete this note?')) return;
    await supabase.storage.from('notes-files').remove([note.file_path]);
    await supabase.from('notes').delete().eq('id', note.id);
    loadData();
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return ImageIcon;
    if (fileType.includes('pdf')) return FileText;
    if (fileType.includes('word') || fileType.includes('document')) return FileType;
    return File;
  };

  if (!loading && !topic) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <FileText size={48} className="text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-700">Topic not found</h3>
          <Link to="/dashboard" className="mt-4 inline-flex items-center gap-1.5 text-blue-600 font-medium">
            <ArrowLeft size={16} /> Back to subjects
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50">
      {/* Breadcrumb header */}
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
          <button
            onClick={() => navigate(`/subject/${topic?.subject.id}`)}
            className="flex items-center gap-1.5 text-slate-400 hover:text-slate-700 text-sm mb-3 transition-colors"
          >
            <ArrowLeft size={16} /> {topic?.subject.name}
          </button>
          <div className="flex items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">{topic?.name}</h1>
              {topic?.description && (
                <p className="mt-1 text-slate-500">{topic.description}</p>
              )}
            </div>
            {user && (
              <button
                onClick={() => setShowUploadModal(true)}
                className="hidden sm:flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-[1.02] transition-all shrink-0"
              >
                <Upload size={18} /> Upload
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-slate-700">
            Notes {notes.length > 0 && `(${notes.length})`}
          </h2>
          {user && (
            <button
              onClick={() => setShowUploadModal(true)}
              className="sm:hidden flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold shadow-lg shadow-blue-500/25 transition-all"
            >
              <Upload size={16} /> Upload
            </button>
          )}
        </div>

        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-24 rounded-2xl bg-white border border-slate-100 animate-pulse" />
            ))}
          </div>
        ) : notes.length === 0 ? (
          <div className="text-center py-16 rounded-2xl bg-white border border-slate-100">
            <FileText size={40} className="text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-slate-700">No notes available</h3>
            <p className="mt-1 text-slate-500">
              {user ? 'Be the first to upload notes for this topic' : 'Check back soon for notes'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {notes.map((note) => {
              const Icon = getFileIcon(note.file_type);
              const isOwner = user?.id === note.uploader_id;
              return (
                <div
                  key={note.id}
                  className="group flex items-center gap-4 p-5 rounded-2xl bg-white border border-slate-100 hover:shadow-md hover:border-slate-200 transition-all"
                >
                  <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                    <Icon size={22} className="text-slate-400" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-slate-900 truncate">{note.title}</h3>
                    {note.description && (
                      <p className="text-sm text-slate-500 truncate">{note.description}</p>
                    )}
                    <div className="mt-1.5 flex items-center gap-3 text-xs text-slate-400">
                      <span className="truncate max-w-[160px]">{note.file_name}</span>
                      <span>{formatBytes(note.file_size)}</span>
                      <span className="flex items-center gap-1">
                        <Download size={12} /> {note.downloads}
                      </span>
                      <span className="hidden sm:inline">{timeAgo(note.created_at)}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleDownload(note)}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-50 text-blue-600 font-medium text-sm hover:bg-blue-100 transition-colors"
                    >
                      <Download size={16} />
                      <span className="hidden sm:inline">Download</span>
                    </button>

                    {isOwner && (
                      <div className="flex gap-1">
                        <button
                          onClick={() => setEditingNote(note)}
                          className="p-2 rounded-lg text-slate-300 hover:text-blue-600 transition-colors"
                        >
                          <Pencil size={15} />
                        </button>
                        <button
                          onClick={() => handleDeleteNote(note)}
                          className="p-2 rounded-lg text-slate-300 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {user && (
        <UploadModal
          open={showUploadModal}
          onClose={() => setShowUploadModal(false)}
          onSaved={loadData}
          topicId={topicId}
        />
      )}

      {user && editingNote && (
        <EditNoteModal
          open={!!editingNote}
          onClose={() => setEditingNote(null)}
          onSaved={loadData}
          note={editingNote}
        />
      )}
    </div>
  );
}

function UploadModal({
  open,
  onClose,
  onSaved,
  topicId,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  topicId: string;
}) {
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setTitle('');
      setDescription('');
      setFile(null);
      setError(null);
    }
  }, [open]);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) setFile(f);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !user) return;
    setSaving(true);
    setError(null);

    const ext = file.name.split('.').pop();
    const filePath = `${user.id}/${crypto.randomUUID()}.${ext}`;

    const { error: uploadError } = await supabase.storage
      .from('notes-files')
      .upload(filePath, file);

    if (uploadError) {
      setError(uploadError.message);
      setSaving(false);
      return;
    }

    const { error: dbError } = await supabase.from('notes').insert({
      topic_id: topicId,
      title,
      description,
      file_path: filePath,
      file_name: file.name,
      file_size: file.size,
      file_type: file.type || 'application/octet-stream',
    });

    setSaving(false);
    if (dbError) {
      setError(dbError.message);
    } else {
      onSaved();
      onClose();
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Upload Notes">
      <form onSubmit={handleSave} className="space-y-4">
        <Input
          label="Title"
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. Quick Sort — Lecture 5 Notes"
        />
        <Textarea
          label="Description"
          rows={2}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="What's in this file?"
        />

        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          className={`cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-colors ${
            dragging
              ? 'border-blue-500 bg-blue-50'
              : file
                ? 'border-emerald-400 bg-emerald-50'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
          }`}
        >
          <input
            ref={fileRef}
            type="file"
            className="hidden"
            accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.gif,.ppt,.pptx,.xls,.xlsx,.zip,.md"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          />
          {file ? (
            <div className="flex items-center justify-center gap-2 text-emerald-600">
              <File size={20} />
              <span className="font-medium">{file.name}</span>
              <span className="text-sm text-slate-400">({formatBytes(file.size)})</span>
            </div>
          ) : (
            <div className="text-slate-500">
              <Upload size={28} className="mx-auto mb-2 text-slate-400" />
              <p className="font-medium">Click to select or drag a file here</p>
              <p className="text-xs text-slate-400 mt-1">PDF, DOCX, TXT, images, and more</p>
            </div>
          )}
        </div>

        {error && (
          <div className="px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-600">
            {error}
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-medium hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving || !file}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50 disabled:hover:shadow-none"
          >
            {saving ? 'Uploading...' : 'Upload Note'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function EditNoteModal({
  open,
  onClose,
  onSaved,
  note,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  note: Note;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setTitle(note.title);
      setDescription(note.description);
      setError(null);
    }
  }, [open, note]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const { error: err } = await supabase
      .from('notes')
      .update({ title, description })
      .eq('id', note.id);

    setSaving(false);
    if (err) {
      setError(err.message);
    } else {
      onSaved();
      onClose();
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Edit Note">
      <form onSubmit={handleSave} className="space-y-4">
        <Input
          label="Title"
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <Textarea
          label="Description"
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        {error && (
          <div className="px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-sm text-red-600">
            {error}
          </div>
        )}
        <div className="flex gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 font-medium hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
