/*
# Student Notes Sharing Platform — Schema

## Overview
Creates the core data model for a student notes sharing platform:
- Students (profiles) extend Supabase auth.users
- Subjects group related topics
- Topics belong to subjects
- Notes (files) belong to topics and are uploaded by students

## Tables

### subjects
- id (uuid, PK)
- name (text, unique, not null)
- code (text, unique, not null) — e.g. "CS101"
- description (text)
- color (text) — UI accent color
- created_at (timestamptz)

### topics
- id (uuid, PK)
- subject_id (uuid, FK → subjects, CASCADE)
- name (text, not null)
- description (text)
- created_at (timestamptz)

### notes
- id (uuid, PK)
- topic_id (uuid, FK → topics, CASCADE)
- uploader_id (uuid, FK → auth.users, CASCADE)
- title (text, not null)
- description (text)
- file_path (text, not null) — storage path
- file_name (text, not null) — original filename
- file_size (bigint) — bytes
- file_type (text) — mime type
- downloads (integer, default 0)
- created_at (timestamptz)

## Security
- RLS enabled on all tables
- subjects: public read (anon+authenticated), insert/update/delete by authenticated users
- topics: public read, insert/update/delete by authenticated users
- notes: public read, insert by authenticated (uploader), update/delete by owner only
- Storage bucket "notes-files" is public for read, authenticated for write
*/

-- Subjects table
CREATE TABLE IF NOT EXISTS subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL,
  description text DEFAULT '',
  color text DEFAULT '#3b82f6',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_subjects" ON subjects;
CREATE POLICY "read_subjects" ON subjects FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_subjects" ON subjects;
CREATE POLICY "insert_subjects" ON subjects FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_subjects" ON subjects;
CREATE POLICY "update_subjects" ON subjects FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_subjects" ON subjects;
CREATE POLICY "delete_subjects" ON subjects FOR DELETE
  TO authenticated USING (true);

-- Topics table
CREATE TABLE IF NOT EXISTS topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id uuid NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE topics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_topics" ON topics;
CREATE POLICY "read_topics" ON topics FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_topics" ON topics;
CREATE POLICY "insert_topics" ON topics FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_topics" ON topics;
CREATE POLICY "update_topics" ON topics FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_topics" ON topics;
CREATE POLICY "delete_topics" ON topics FOR DELETE
  TO authenticated USING (true);

-- Notes table
CREATE TABLE IF NOT EXISTS notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  uploader_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  file_path text NOT NULL,
  file_name text NOT NULL,
  file_size bigint DEFAULT 0,
  file_type text DEFAULT '',
  downloads integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_notes" ON notes;
CREATE POLICY "read_notes" ON notes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_notes" ON notes;
CREATE POLICY "insert_notes" ON notes FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_own_notes" ON notes;
CREATE POLICY "update_own_notes" ON notes FOR UPDATE
  TO authenticated USING (auth.uid() = uploader_id) WITH CHECK (auth.uid() = uploader_id);

DROP POLICY IF EXISTS "delete_own_notes" ON notes;
CREATE POLICY "delete_own_notes" ON notes FOR DELETE
  TO authenticated USING (auth.uid() = uploader_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_topics_subject_id ON topics(subject_id);
CREATE INDEX IF NOT EXISTS idx_notes_topic_id ON notes(topic_id);
CREATE INDEX IF NOT EXISTS idx_notes_uploader_id ON notes(uploader_id);

-- Storage bucket for note files
INSERT INTO storage.buckets (id, name, public)
VALUES ('notes-files', 'notes-files', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
DROP POLICY IF EXISTS "read_notes_files" ON storage.objects;
CREATE POLICY "read_notes_files" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'notes-files');

DROP POLICY IF EXISTS "insert_notes_files" ON storage.objects;
CREATE POLICY "insert_notes_files" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'notes-files');

DROP POLICY IF EXISTS "update_notes_files" ON storage.objects;
CREATE POLICY "update_notes_files" ON storage.objects FOR UPDATE
  TO authenticated USING (bucket_id = 'notes-files');

DROP POLICY IF EXISTS "delete_notes_files" ON storage.objects;
CREATE POLICY "delete_notes_files" ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'notes-files');